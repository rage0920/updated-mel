#include <gmp.h>
#include "gmpecc.h"

void Point_Doubling(struct Point *P, struct Point *R){
	char str_ax[132], str_ay[132]; //, str_rv[132];
	//memset(str_rv, 0, 131);
	get_str_repr(P, true, str_ax);
	gmp_snprintf(str_ay, 67, "02%0.64Zx", P->y);
	std::string a_secpx = std::string(str_ax), a_secpy = std::string(str_ay);
	secp256k1::uint256 _apx(a_secpx), _apy(a_secpy);
	secp256k1::ecpoint _ap(a_secpx, a_secpy);

	secp256k1::ecpoint rv = secp256k1::doublePoint(_ap);
	
	mpz_set_str(R->x, rv.x.toString().c_str(), 16);
	mpz_set_str(R->y, rv.y.toString().c_str(), 16);
}
void Point_Addition(struct Point *P, struct Point *Q, struct Point *R){
	//Logger::log(LogLevel::Info, "Inside the new Point Addition function.");
	secp256k1::ecpoint _pp, _qp;

	if (!(mpz_cmp_ui(P->x, 0) == 0 && mpz_cmp_ui(P->y, 0) == 0)){
		char str_px[67], str_py[67];
		gmp_snprintf(str_px, 67, "02%0.64Zx", P->x);
		gmp_snprintf(str_py, 67, "02%0.64Zx", P->y);
		std::string p_secpx = std::string(str_px), p_secpy = std::string(str_py);
		secp256k1::uint256 _ppx(p_secpx), _ppy(p_secpy);
		_pp.x = _ppx;
		_pp.y = _ppy;
	}

	if (!(mpz_cmp_ui(Q->x, 0) == 0 && mpz_cmp_ui(Q->y, 0) == 0)) {
		char str_qx[67], str_qy[67];
		// get_str_repr(Q, true, str_qx);
		gmp_snprintf(str_qx, 67, "02%0.64Zx", Q->x);
		gmp_snprintf(str_qy, 67, "02%0.64Zx", Q->y);
		std::string q_secpx = std::string(str_qx), q_secpy = std::string(str_qy);
		secp256k1::uint256 _qpx(q_secpx), _qpy(q_secpy);		
		_qp.x = _qpx;
		_qp.y = _qpy;
	}

	// Logger::log(LogLevel::Info, "Setting the first point.");


	//printf("Iside the new addition: \n");
	//printf("%s\n%s\n", str_qx, q_secpx.c_str());
	// secp256k1::uint256 _qpx(q_secpx), _qpy(q_secpy);
	//secp256k1::ecpoint _qp(q_secpx, q_secpy);
	// secp256k1::ecpoint _qp(_qpx, _qpy);
	// Logger::log(LogLevel::Info, "Setting the second point.");
	secp256k1::ecpoint rv = secp256k1::addPoints(_qp, _pp);

	mpz_set_str(R->x, rv.x.toString().c_str(), 16);
	mpz_set_str(R->y, rv.y.toString().c_str(), 16);

}

void get_str_repr(struct Point *publickey,bool compress,char *dst)	{
	memset(dst,0,131);
	if(compress)	{
		if(mpz_tstbit(publickey->y, 0) == 0)	{	// Even
			gmp_snprintf (dst,67,"02%0.64Zx",publickey->x);
		}
		else	{
			gmp_snprintf(dst,67,"03%0.64Zx",publickey->x);
		}
	}
	else	{
		gmp_snprintf(dst,131,"04%0.64Zx%0.64Zx",publickey->x,publickey->y);
	}

}


// void Point_Doubling(struct Point *P, struct Point *R){
// 	// Point_Doubling_secp(P, R);
// 	// char x[132];
// 	// get_str_repr(R, false, x);

// 	// printf("Inside the original doubling\nsecx: %s\n", x);

// 	mpz_t slope, temp;
// 	mpz_init(temp);
// 	mpz_init(slope);
// 	if(mpz_cmp_ui(P->y, 0) != 0) {
// 		mpz_mul_ui(temp, P->y, 2);
// 		mpz_invert(temp, temp, EC.p);
// 		mpz_mul(slope, P->x, P->x);
// 		mpz_mul_ui(slope, slope, 3);
// 		mpz_mul(slope, slope, temp);
// 		mpz_mod(slope, slope, EC.p);
// 		mpz_mul(R->x, slope, slope);
// 		mpz_sub(R->x, R->x, P->x);
// 		mpz_sub(R->x, R->x, P->x);
// 		mpz_mod(R->x, R->x, EC.p);
// 		mpz_sub(temp, P->x, R->x);
// 		mpz_mul(R->y, slope, temp);
// 		mpz_sub(R->y, R->y, P->y);
// 		mpz_mod(R->y, R->y, EC.p);
// 	} else {
// 		mpz_set_ui(R->x, 0);
// 		mpz_set_ui(R->y, 0);
// 	}
// 	// get_str_repr(R, false, x);
// 	// printf("orix: %s\n", x);
// 	mpz_clear(temp);
// 	mpz_clear(slope);

// }

// void Point_Addition(struct Point *P, struct Point *Q, struct Point *R)	{
// 	// char x[132];
// 	// Point_Addition_secp(P, Q, R);
// 	// get_str_repr(R, false, x);
// 	// printf("Inside the original addition\nsecx: %s\n", x);

// 	mpz_t PA_temp,PA_slope;
// 	mpz_init(PA_temp);
// 	mpz_init(PA_slope);
// 	if(mpz_cmp_ui(P->x, 0) == 0 && mpz_cmp_ui(P->y, 0) == 0) {

// 		mpz_set(R->x, Q->x);
// 		mpz_set(R->y, Q->y);
// 	}
// 	else	{
// 		if(mpz_cmp_ui(Q->x, 0) == 0 && mpz_cmp_ui(Q->y, 0) == 0) {
// 			mpz_set(R->x, P->x);
// 			mpz_set(R->y, P->y);
// 		}
// 		else	{
// 			if(mpz_cmp_ui(Q->y, 0) != 0) {
// 				mpz_sub(PA_temp, EC.p, Q->y);
// 				mpz_mod(PA_temp, PA_temp, EC.p);
// 			}
// 			else	{
// 				mpz_set_ui(PA_temp, 0);
// 			}
// 			if(mpz_cmp(P->y, PA_temp) == 0 && mpz_cmp(P->x, Q->x) == 0) {
// 				mpz_set_ui(R->x, 0);
// 				mpz_set_ui(R->y, 0);
// 			}
// 			else	{
// 				if(mpz_cmp(P->x, Q->x) == 0 && mpz_cmp(P->y, Q->y) == 0)	{
// 					Point_Doubling(P, R);
// 				}
// 				else {
// 					mpz_set_ui(PA_slope, 0);
// 					mpz_sub(PA_temp, P->x, Q->x);	//dx = B.x - A.x
// 					mpz_mod(PA_temp, PA_temp, EC.p);		///dx = dx % p
// 					mpz_invert(PA_temp, PA_temp, EC.p);	//gmpy2.invert(dx, p) % p
// 					mpz_sub(PA_slope, P->y, Q->y);
// 					mpz_mul(PA_slope, PA_slope, PA_temp);
// 					mpz_mod(PA_slope, PA_slope, EC.p);
// 					mpz_mul(R->x, PA_slope, PA_slope);	//c*c
// 					mpz_sub(R->x, R->x, P->x);	//	c*c - A.x
// 					mpz_sub(R->x, R->x, Q->x);	//(c*c - A.x) -	B.x
// 					mpz_mod(R->x, R->x, EC.p);	// Rx % p
// 					mpz_sub(PA_temp, P->x, R->x);
// 					mpz_mul(R->y, PA_slope, PA_temp);
// 					mpz_sub(R->y, R->y, P->y);
// 					mpz_mod(R->y, R->y, EC.p);
// 				}
// 			}
// 		}
// 	}
// 	// char orix[132];
// 	// get_str_repr(R, false, orix);
// 	// printf("orix: %s\n", orix);
// 	mpz_clear(PA_temp);
// 	mpz_clear(PA_slope);
// 	// if (strncmp(x, orix, 132)){
// 	// 	char str_px[67], str_py[67], str_p[132];
// 	// 	// get_str_repr(P, true, str_px);
// 	// 	gmp_snprintf(str_px, 67, "02%0.64Zx", P->x);
// 	// 	gmp_snprintf(str_py, 67, "02%0.64Zx", P->y);
// 	// 	std::string p_secpx = str_px, p_secpy = str_py;
// 	// 	secp256k1::uint256 _ppx(p_secpx), _ppy(p_secpy);
// 	// 	secp256k1::ecpoint _pp(_ppx, _ppy);
// 	// 	get_str_repr(P, false, str_p);
// 	// 	printf("porix: %s\npsecx: %s\n", str_p, _pp.toString().c_str());
// 	// 	char str_qx[67], str_qy[67], str_q[132];
// 	// 	// get_str_repr(Q, true, str_qx);
// 	// 	gmp_snprintf(str_qx, 67, "02%0.64Zx", Q->x);
// 	// 	gmp_snprintf(str_qy, 67, "02%0.64Zx", Q->y);
// 	// 	get_str_repr(Q, false, str_q);
// 	// 	std::string q_secpx = std::string(str_qx), q_secpy = std::string(str_qy);
// 	// 	//printf("Iside the new addition: \n");
// 	// 	//printf("%s\n%s\n", str_qx, q_secpx.c_str());
// 	// 	secp256k1::uint256 _qpx(q_secpx), _qpy(q_secpy);
// 	// 	secp256k1::ecpoint _qp(_qpx, _qpy);
// 	// 	printf("qorix: %s\nqsecx: %s\n", str_q, _qp.toString().c_str());
// 	// 	// secp256k1::ecpoint _qp(_qpx, _qpy);
// 	// 	secp256k1::ecpoint rv = secp256k1::addPoints(_qp, _pp);
// 	// 	printf("ssecr: %s\n", rv.toString().c_str());
// 	// 	exit(1);
// 	// }
// }

void Scalar_Multiplication(struct Point P, struct Point *R, mpz_t m)	{
	struct Point SM_T,SM_Q,Dumm;
	int no_of_bits, i;
	no_of_bits = mpz_sizeinbase(m, 2);
	mpz_init_set_ui(SM_Q.x,0);
	mpz_init_set_ui(SM_Q.y,0);
	mpz_init_set_ui(SM_T.x,0);
	mpz_init_set_ui(SM_T.y,0);
	mpz_init_set_ui(Dumm.x,0);
	mpz_init_set_ui(Dumm.y,0);

	mpz_set_ui(R->x, 0);
	mpz_set_ui(R->y, 0);
	if(mpz_cmp_ui(m, 0) != 0)	{
		mpz_set(SM_Q.x, P.x);
		mpz_set(SM_Q.y, P.y);
		for(i = 0; i < no_of_bits; i++) {
			if(mpz_tstbit(m, i))	{
				mpz_set(SM_T.x, R->x);
				mpz_set(SM_T.y, R->y);
				mpz_set(SM_Q.x,DoublingG[i].x);
				mpz_set(SM_Q.y,DoublingG[i].y);
				Point_Addition(&SM_T, &SM_Q, R);
			}
			else	{	/* Doing exactly the same operations but with destination dummy */
				mpz_set(Dumm.x, R->x);
				mpz_set(Dumm.y, R->y);
				mpz_set(Dumm.x,DoublingG[i].x);
				mpz_set(Dumm.y,DoublingG[i].y);
				Point_Addition(&SM_T, &SM_Q, &Dumm);
			}
		}
	}
	mpz_clear(Dumm.x);
	mpz_clear(Dumm.y);
	mpz_clear(SM_T.x);
	mpz_clear(SM_T.y);
	mpz_clear(SM_Q.x);
	mpz_clear(SM_Q.y);
}

void Point_Negation(struct Point *A, struct Point *S){
	if(mpz_cmp_ui(A->x,0) != 0 && mpz_cmp_ui(A->y,0) != 0){
		mpz_sub(S->y, EC.p, A->y);
		mpz_set(S->x, A->x);
	}
	else	{
                mpz_set(S->y, A->y);
                mpz_set(S->x, A->x);
	}
}

/*
	Precalculate G Doublings for Scalar_Multiplication
*/
void init_doublingG(struct Point *P)	{
	int i = 0;
	mpz_init(DoublingG[i].x);
	mpz_init(DoublingG[i].y);
	mpz_set(DoublingG[i].x,P->x);
	mpz_set(DoublingG[i].y,P->y);
	i = 1;
	while(i < 256){
		mpz_init(DoublingG[i].x);
		mpz_init(DoublingG[i].y);
		Point_Doubling(&DoublingG[i-1] ,&DoublingG[i]);
		mpz_mod(DoublingG[i].x, DoublingG[i].x, EC.p);
		mpz_mod(DoublingG[i].y, DoublingG[i].y, EC.p);
		i++;
	}
}
