```
apt update && apt upgrade
apt install git -y
apt install build-essential -y
apt install libssl-dev
apt install libgcrypt20-dev
apt install libgmp-dev

```
Compile:

make


example:

```./mel 0356f6e0b3fbed3c4f1f731a29128727e076e434f11741df7c5d4428b5fade60c5 - 10```

output:
```Result: 02bbaa731ab8a498b0fbbc18b0a19d1248e957ef44ff001b2a9843f24adc123a6f```
