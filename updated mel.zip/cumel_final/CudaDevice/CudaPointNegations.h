#ifndef _CUDA_POINT_NEGATIONS_H
#define _CUDA_POINT_NEGATIONS_H

#include <cuda.h>
#include <cuda_runtime.h>

#include <vector>
#include "../Secp256k1/secp256k1.h"

class CudaDeviceNegations {
    public:
        CudaDeviceNegations()
        {
            _numNegations = 0;
            _devX = NULL;
            _devY = NULL;
            _devPrivate = NULL;
            _devChain = NULL;
            _devBasePointX = NULL;
            _devBasePointY = NULL;
            _step = 0;
        }
        ~CudaDeviceNegations(){
            /*
            Need to write clear functions here.
            */
        }

        cudaError_t init(int blocks, int threads, int pointsPerThread, const std::vector<secp256k1::uint256>&   negationPoints);
        cudaError_t reInit(int blocks, int threads, int pointsPerThread, const std::vector<secp256k1::uint256>& negationPoints);
        
        bool selfTest(const std::vector<secp256k1::uint256>& negationPoints);

        cudaError_t doStep();

    private:
        int _blocks;
        int _threads;
        int _pointsPerThread;
        unsigned int _numPoints;

        unsigned int* _devX;
        unsigned int* _devY;
        unsigned int* _devPrivate;
        unsigned int* _devChain;
        unsigned int* _devBasePointX;
        unsigned int* _devBasePointY;

        int _step;

        int getIndex(int block, int thread, int idx);

        void splatBigInt(unsigned int* dest, int block, int thread, int idx, const secp256k1::uint256& i);
        secp256k1::uint256 readBigInt(unsigned int* src, int block, int thread, int idx);

        cudaError_t allocateChainBuf(unsigned int count);

        cudaError_t initializeBasePoints();
        cudaError_t reInitializeBasePoints();
};



#endif